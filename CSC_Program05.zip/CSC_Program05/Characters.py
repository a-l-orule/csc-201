from Treasure import *
from Level import *


from random import randrange
#General Character class ro help create player class                            
class Character:
    def __init__(self):
                              
        self.name = ""
                              
        self.health = 100

    #design and equation for battle function taken from simple RPG example 
                              
    def battle(self, player, monster):

        
        damage = min(max(randit(0, self.health) - randint(0, monster.health),0), monster.health)
       
        enemy.health = enemy.health - damage

                              
        if damage == 0:
            print(monster.name + "evades attack from" + self.name )

        else:
            print(self.name + "hurt the " + enemy.name)
                              
    return enemy.health <= 0

#Extra credit monster object
                              
class Monster(Character):

    def __init__(self):

        self.health = randrange(15)

        self.name_monster = "Ogre"
        
#Class designated for all player functions 
class player(Character):
                              
   move_command = ('h':(-1,0), 'k':(0,1) "j":(0,-1), 'l':(1,0))

    def __init__(self, spot_in_level):

        self.name = "starter"

        self. health = 100
                              
        self.spot_in_level = spot_in_level

        self.location = spot_in_level.starting_point()

        stash = []
                              
#function for the movements of the player's movements
#sampledfrom simple RPG
                              
    def move(self, commands):
                              
        if commands == 'h':
                              
            (dx, dy)= (-1,0)
                              
        elif commands == 'k':
                              
            (dx, dy)= (0,1)
                              
        elif commands == 'j':
                              
            (dx, dy)= (0,-1)
                              
        elif commands == 'l':
                              
            (dx, dy)= (1,0)
                        
        
     new_x = self.location[0] + dx
                              
     new_y = self. location[1] + dy

#keeping the player in the perameters of the level
        if self.spotin_level.isvalid location(new_x, new_y):
                              
            self.location = (new_x, new_y)
                              
            str_note = "Alright"
                              
        else:
                              
            str_note = "That move isnt allowed"
                              
        return str_note
    
# Return location of the player                          
    def get_location(self):
                              
        return self.location

#Function for picking up and indexing picked up items 
    def pickup(self, item):
                              
        self.stash.append(item)
                              
        print("You pick and item up")
                              
        item.pickup()
                              
#Printing indexed inventory items                              
    def print_stash(self):
                              
        indexed_item = 1
                              
        for item in self.stash:
                              
            print("(" + str(indexed_item) + ")\t" + str(item))
                              
            indexed_item += 1

    
                              
        
        

        

        

