from Level import *
from Treasure import *
from Characters import *



#Establish how the levels will kept and where th player is 
spot_in_level = level()

store_level = [spot_in_level]

avatar= Player(spot_in_level)

spot_in_level.print_level(avatar)



# Game loop for game play
play_game = True
while play_game:

    play_command = input("enter command: ")

    #  get user command
    if play_command == "h" or play_command == "j" or play_command == "k" or play_command == "l":
        # if grid square to the left is within bounds
        reaction = avatar.move(play_command)

    elif play_command == "i": 
        reaction = "Inventory Is Empty"
    else:
       play_command == "i" and self.stash != []
       result = self.stash

    spot_in_level.print_level(avatar)



