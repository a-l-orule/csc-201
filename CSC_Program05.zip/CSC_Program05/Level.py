
from Treasure import *
from Player import *

class Level(item):
    # set variables for specific level objects to create level perameters 
    Empyt = "."
    Wall = "#"
    Up_level = "u"
    Down_level = "d"
    TREASURE= "*"
    Warrior = "P"
    Monster = "M"
    
    def new_location_area(self):

        empty_cell = False
               
        while not empty_cell:

            x = randint(1, self.width-2)
            
            y = randint(1, self.height-2)

            if self.grid[y][x] == EMPTY:
                
                empty_cell = True
                
            # if the self.grid cell at (x, y) is not empty, roll again
            
        return (x, y)
    
    def __init__(self):
        
        self.width = random.randint(10,40)
        
        self.height = random.randint(15,20)
       
        # create self.grid
        # create horizontal wall
        
        side_wall = self.__width*Wall
        
        middle_grid = Wall + (self.width-2)*Empty + Wall

        self.grid = [side_wall]
        
        for row in range (1,self.height-1):
            
            self.grid.append(middle_grid)
            
        self.grid.append(side_wall)

        # create stairs
        
        (self.up_x, self.up_y) = self.new_location_area()
        
        step = self.grid[self.up_y]
        
        step = line[:self.up_x] + Up_level + line[self.up_x+1:]
        
        self.grid[self.up_y] = line
        
        (self.down_x, self.down_y) = self.new_location_area()
        
        step = self.grid[self.down_y]
        
        step = step[:self.down_x] + Down_level + step[self.down_x+1:]
        
        self.grid[self.down_y] = step


        # create treasure
        # random number of piles
        
        num_pile = random.randint(1, 5)
        
        self.chest_list = {}

        for pile in range (0, num_pile):
            
            # create a treasure pile
            
            num_chest = 3
            
            treasures = []

            # repeat
            
            for k in range(0, num_chest):
                
                # select randomly the object's type
                
                chest = random.randint(0, len(chest_item)-1)
                
                # create the object
                
                the_item = Treasure(chest_item[chest])
                
                # add to the list
                
                treasures.append(the_item)

            # random location or pile
            
            (x, y) = self.new_location_area()
            
            step = self.__grid[y]
            
            step = step[:x] + TREASURE + step[x+1:]

            self.grid[y] = step

            self.chest_list[str((x,y))] = treasures
            
     # display the current level self.__grid
     
    def __str__(self, player):

        (player_x, player_y) = player.get_location() 

        str_note = "\n\n"
        
        for row in range(0, self.height):
            
            if row != player_y:

                str_note += self.grid[row] + "\n"
                
            else:
                
                step = self.grid[row]
                
                step = step[:player_x] + Player + line[player_x+1:]
                
                str_note += step + "\n"
                
        str_note += "\n"
        
        return str_note


    # display the current level self.grid
    
    def print_level(self, player):

        (player_x, player_y) = player.get_location() 

        str_note = "\n\n"
        
        for row in range(0, self.height):
            
            if row != player_y:
                
                str_note += self.grid[row] + "\n"
                
            else:
                
                step = self.grid[row]
                
                step = step[:player_x] + Player + step[player_x+1:]
                
                str_note += step + "\n"
                
        str_note += "\n"
        
        print(str_note)


    def get_up_point(self):
        
        return (self.up_x, self.up_y)
    
    def get_down_point(self):
        
        return (self.down_x, self.down_y)

    def is_valid_location(self, x, y):
        
        return self.__grid[y][x] != Wall

    


