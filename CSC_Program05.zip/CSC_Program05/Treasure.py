#Abdul-Lateef Orulebaja
#Program 5

#import randint from random module.
from random import randint

#make essential values into list to be used globally
chest_item= ['armor', 'weapon', 'food', 'gold']

food_value = [('bread', 1), ('fruit and berries', 2), ('turkey leg', 5)]
               
weapons_op = [('long knife', 2), ('Spine Sword', 5), ('Thunder Axe', 7)]


class Trearsue(object):

#initialize basis for treasure class
    def __init__(self,chest):
        
        self.chest = chest
        
        self.carried = False
        
#create conditions that allow objects to be selected at random
# from the chest 
        if chest == 'armor':
            self.ac = randint(1,10)
               
            self.value = 25*self.ac
               
            self.worn = False
               
            self.decription = "Basic Armor"
               
        elif chest == 'weapon':
            weapon_choice = randint(0, len(weapons_op)-1)
               
            self.attack = weapon_choice[weapons_op][1]
               
            self.value = 10*self.attack
               
            self.wield = False
               
            self.decription = weapon_choice[weapons_op][0]
               
        elif chest == 'food':
            
            food_op = randint(0, len(food_value0-1)
            
            self.health_help = food_value[food_op][1]
                                 
            self.value = 2*self.health_help
                                 
            self.decription = food_value[food_op][0] 

        else chest == 'gold':
                              
            self.value = randint(1,50)
                              
            self.description = "Gold"

            self.location = (-1,-1)

# string statements that notify user of results of item choosen at random                              
    def __str__(self):
                              
        str_note = "hoorah"
                              
        if self.chest = 'armor':
                              
            str_note = self.description + "is worth" + str(self.value) + "gp"
                              
        elif self.chest = 'weapon':
                              
            str_note = self.description + "is worth" + str(self.value) + "gp"
                              
        elif self.chest == 'food':
                              
            str_note = self.description + "is worth" + str(self.value) + "gp"
                              
        else self.chest == 'gold':
                              
            str_note = str(self.value) + 'coins'
                              
        return str_note
                              
#creating location functions for the items and basis for other object locator
    def location(self, row, colomn):
                              
        self.location = location
                              
        self.location = (row, coloumn)
                              
#retrieving location when need
    def get_location(self):
                              
        return self.location
                              
#specified function for in game actions

#function to pick up items                                
    def pickup(self):

        self.carried = True
                              
#function to drop items
    def drop(self, location):

        self.carried = False

        set_location(location)
                              
#function to wear armor
    def wear(self):
                              
        if self.isworn == True:
                              
            reaction = "You have armor on already"
                              
        else:
                              
            if self.isworn == False:
                              
                self.carried.append(armor)
                              
                reaction = "You do not have armor on"
                              
        return reaction

#function to remove armor 
    def remove(self):
                              
        if self.isworn == False:
                              
            recation = "You don't have armor on"
                              
        else:
                              
            if self.isworn == True:
                              
                self.caarried.remove(armor)
                              
                reaction = " You took your armor off"
                              
        return reaction

#function to wield weapon
    def wield(self):
        if self.isholding == True:
                              
             reaction = "You are carrying a weapon"

        else:
            self.isholding == False:

                reaction = "You are not carrying a weapon"

                self.carried.append(weapon)

        return reaction

#function to drop weapon
    def unwield(self):
        if self.isholding== False:
                              
             reaction = "You dont have a weapon"

        else:
            self.isholding == true:

                reaction = "You dropped your weapon"

                self.carried.append(weapon)

        return  reaction

