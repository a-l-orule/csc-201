from __future__ import print_function
from test_site import pyramid
from wsgiref.simple_server import make_server

 #part 1
# creating function to call in interface
def myapp(environ, start_response):
#Http headers
    response_headers = [('content-type', 'text/plain')]
    start_response('200 OK', response_headers)
#Return shape function import
    return [pyramid(10)]
#simplify myapp function
app = myapp
#initiate server
httpd = make_server('', 8080, app)
print("Starting the server on port 8080")
httpd.serve_forever()


#part 2 
# creating function to call in interface function
def myapp(environ, start_response):
    response_headers = [('content-type', 'text/plain')]
    start_response('200 OK', response_headers)
    return [pyramid(10)]
 
#Create middleware class object
class Middleware:
#initiate class by calling perameter
    def __init__(self, app):
        self.wrapped_app = app
#call function 
    def __call__(self, environ, start_response):
 
        def custom_start_response(status, headers, exc_info=None):
            return start_response(status, headers, exc_info)
 
        return self.wrapped_app(environ, custom_start_response)
#use middleware class to open app 
app = Middleware(myapp)
#initiate server
httpd = make_server('', 8080, app)
print("Starting the server on port 8080")
httpd.serve_forever()


