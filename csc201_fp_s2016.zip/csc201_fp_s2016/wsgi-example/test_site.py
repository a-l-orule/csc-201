
def pyramid(pmid):
	for n in range(1, pmid+1): 
   		space= pmid-n  
   	  	t_angle= space * " " + (2*n-1) * "*" 
    return(t_angle) 

 
 
